package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import io.netty.channel.ChannelFutureListener;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hook vào ClientConnection.send() TAIL — exact pattern từ BOOST-FPS.
 *
 * Lý do dùng packet hook thay vì mixin LivingEntity.stopUsingItem():
 *   1. Không có class hierarchy issue (stopUsingItem trên LivingEntity, không phải ClientPlayerEntity)
 *   2. Fire chính xác khi server nhận tín hiệu — sync với network layer
 *   3. BOOST-FPS log xác nhận: "source=release_use_item" tức là packet này
 *
 * PlayerActionC2SPacket.Action.RELEASE_USE_ITEM gửi khi:
 *   - Player thả chuột phải đang giữ bow (bắn)
 *   - Player thả chuột phải đang giữ crossbow charged (bắn)
 *   - Player thả chuột phải đang ăn/uống (hủy)
 *   → Filter bằng BowItem check trong FireBowRuntime.onReleaseUseItem()
 */
@Environment(EnvType.CLIENT)
@Mixin(ClientConnection.class)
public class ClientConnectionMixin {

    @Inject(
        method = "send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
        at = @At("TAIL")
    )
    private void firebow$onPacketSendPost(
            Packet<?> packet,
            ChannelFutureListener listener,
            boolean flush,
            CallbackInfo ci) {

        // Chỉ quan tâm PlayerActionC2SPacket
        if (!(packet instanceof PlayerActionC2SPacket actionPacket)) return;

        // RELEASE_USE_ITEM = player thả item đang dùng (bow, crossbow, food, shield...)
        if (actionPacket.getAction() != PlayerActionC2SPacket.Action.RELEASE_USE_ITEM) return;

        FireBowRuntime.get().onReleaseUseItem();
    }
}
