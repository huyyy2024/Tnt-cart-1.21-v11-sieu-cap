package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.util.InteractionUtil;
import com.firebow.util.InventoryUtil;
import com.firebow.util.PlacementCalc;
import com.firebow.util.SearchResult;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * FALLBACK ONLY — xử lý arrows mà onReleaseUseItem miss.
 *
 * Primary path: ClientConnectionMixin → onReleaseUseItem()
 *   → calcBowTrajectory() → đặt rail TRƯỚC khi arrow spawn (~0 tick delay)
 *
 * Fallback path (mixin này): arrow đang bay → dự đoán landing từ velocity hiện tại
 *   → chỉ chạy khi primary path chưa schedule pos này
 *   → delay ~10-15 tick (tên phải bay ra mới detect được)
 *
 * Edge cases fallback cover: dispenser fire arrows, skeleton arrows bắn trúng
 *   rail vị trí mình muốn đặt, flame enchant arrows không phải của mình.
 *   Thực tế mod này chỉ care OWN arrows nên fallback chủ yếu là safety net.
 */
@Environment(EnvType.CLIENT)
@Mixin(PersistentProjectileEntity.class)
public class FireArrowMixin {

    @Inject(method = "tick", at = @At("HEAD"))
    private void firebow$onTick(CallbackInfo ci) {
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        PersistentProjectileEntity self = (PersistentProjectileEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (!isOwnArrow(self, mc)) return;
        if (!self.isOnFire()) return;
        if (self.isOnGround()) return;
        if (mc.player == null || mc.interactionManager == null) return;
        if (self.getVelocity().lengthSquared() < 0.0001) return;

        int entityId = self.getId();
        if (rt.isDuplicateArrow(entityId)) return;

        Vec3d pos      = self.getPos();
        Vec3d velocity = self.getVelocity();
        World world    = self.getWorld();

        BlockPos railPos = PlacementCalc.predictLandingRailPos(world, pos, velocity);
        if (railPos == null) return;
        if (!InteractionUtil.inReach(mc.player, railPos)) return;

        // Không đặt ngay dưới chân player
        Vec3d eyes = mc.player.getEyePos();
        if (eyes.squaredDistanceTo(Vec3d.ofCenter(railPos)) < 1.75 * 1.75) return;

        // Còn đủ thời gian không (tránh đặt khi tên sắp cắm đất rồi)
        if (estimateTicksToLand(pos, velocity, railPos) > 20) return;

        // Check inventory ngay tại thời điểm đặt (không cache từ trước — fix bug v4)
        SearchResult railSlot = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
        if (railSlot.isMissing()) return;

        SearchResult cartSlot = InventoryUtil.findItem(Items.TNT_MINECART);
        if (cartSlot.isMissing()) return;

        long ping      = getPingMs(mc);
        int  cartDelay = ping > 200 ? 4 : ping > 100 ? 3 : 2;

        // Chỉ schedule nếu primary path chưa xử lý pos này
        rt.acceptArrowFallback(entityId, railPos, cartDelay);
    }

    // ---- helpers ----

    private int estimateTicksToLand(Vec3d pos, Vec3d vel, BlockPos target) {
        double x = pos.x, y = pos.y, z = pos.z;
        double vx = vel.x, vy = vel.y, vz = vel.z;
        Vec3d t = Vec3d.ofCenter(target);
        for (int i = 0; i < 60; i++) {
            vx *= 0.99; vy = vy * 0.99 - 0.05; vz *= 0.99;
            x += vx; y += vy; z += vz;
            if ((x-t.x)*(x-t.x) + (y-t.y)*(y-t.y) + (z-t.z)*(z-t.z) < 1.5*1.5)
                return i;
        }
        return 60;
    }

    private long getPingMs(MinecraftClient mc) {
        try {
            if (mc.getNetworkHandler() == null || mc.player == null) return 50L;
            var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return e != null ? e.getLatency() : 50L;
        } catch (Exception ignored) { return 50L; }
    }

    private boolean isOwnArrow(PersistentProjectileEntity arrow, MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity owner = arrow.getOwner();
        return owner != null && owner.getId() == mc.player.getId();
    }
}
