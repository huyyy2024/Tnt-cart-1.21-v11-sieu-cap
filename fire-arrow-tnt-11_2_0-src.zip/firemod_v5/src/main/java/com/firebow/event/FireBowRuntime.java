package com.firebow.event;

import com.firebow.util.*;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BowItem;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class FireBowRuntime {

    private static final FireBowRuntime INSTANCE = new FireBowRuntime();
    public static FireBowRuntime get() { return INSTANCE; }

    // ---- State ----
    private volatile boolean enabled = true;

    // Dedup RELEASE_USE_ITEM — tránh trigger 2 lần trong 1 cú bắn
    private volatile long lastReleaseMs = 0L;
    private static final long RELEASE_DEDUP_MS = 300L;

    // Pending placements — key: railPos
    // Rail:  int[3] = { ticksLeft, syncReady(0/1), reserved }
    // Cart:  int[4] = { ticksLeft, retryCount, syncReady(0/1), reserved }
    // Slots KHÔNG cache — lookup fresh mỗi lần đặt (fix bug v4: slot drift khi player swap hotbar)
    private final Map<BlockPos, int[]> pendingRails = new ConcurrentHashMap<>();
    private final Map<BlockPos, int[]> pendingCarts = new ConcurrentHashMap<>();
    private static final int MAX_CART_RETRIES = 8;

    // Fallback dedup cho FireArrowMixin
    private final Map<Integer, Long> acceptedArrows = new ConcurrentHashMap<>();
    private static final long ARROW_DEDUP_MS = 3000L;

    private FireBowRuntime() {}

    public boolean isEnabled() { return enabled; }
    public void    toggle()    { enabled = !enabled; }

    // =================================================================
    // PRIMARY PATH — hook từ ClientConnectionMixin (BOOST-FPS pattern)
    // Gọi khi RELEASE_USE_ITEM packet được gửi lên server
    // =================================================================

    public void onReleaseUseItem() {
        if (!enabled) return;

        long now = System.currentTimeMillis();
        if (now - lastReleaseMs < RELEASE_DEDUP_MS) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;

        // Filter: chỉ xử lý bow (không phải crossbow, food, shield)
        // getActiveItem() = item đang được dùng (held + right-click)
        var activeItem = mc.player.getActiveItem();
        if (activeItem.isEmpty()) return;
        if (!(activeItem.getItem() instanceof BowItem)) return;

        // Phải đang giữ đủ lâu để tên có lực bay
        int useTicks = activeItem.getMaxUseTime() - mc.player.getItemUseTimeLeft();
        if (useTicks < 3) return; // quá ngắn — tên sẽ không đi xa

        // Tính power giống BowItem.onStoppedUsing() vanilla
        float power = useTicks / 20.0f;
        power = (power * power + power * 2.0f) / 3.0f;
        if (power > 1.0f) power = 1.0f;
        if (power < 0.1f) return;

        // Check inventory trước khi tính trajectory — tránh tính vô ích
        if (InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL).isMissing()) return;
        if (InventoryUtil.findItem(Items.TNT_MINECART).isMissing()) return;

        // === BOOST-FPS: calcBowTrajectory(power) ===
        BlockPos railPos = BowTrajectory.calcLandingPos(mc.player, power);
        if (railPos == null) return;

        // Phải trong tầm đặt
        if (!InteractionUtil.inReach(mc.player, railPos)) return;

        // Không đặt ngay dưới chân player
        Vec3d eyes = mc.player.getEyePos();
        if (eyes.squaredDistanceTo(Vec3d.ofCenter(railPos)) < 1.75 * 1.75) return;

        lastReleaseMs = now;

        // Delay dựa vào ping — đảm bảo server nhận packet đặt rail đúng lúc
        long ping      = PingUtil.getPingMs(mc);
        int  cartDelay = ping > 200 ? 5 : ping > 100 ? 3 : 2;

        // tick=0 → đặt rail trong beforeSync ngay tick tiếp theo
        pendingRails.put(railPos, new int[]{ 0, 0, 0 });
        pendingCarts.put(railPos, new int[]{ cartDelay, 0, 0, 0 });
    }

    // =================================================================
    // FALLBACK PATH — từ FireArrowMixin (arrow đang bay)
    // Chỉ chạy khi primary path chưa schedule pos này
    // =================================================================

    public boolean isDuplicateArrow(int entityId) {
        Long last = acceptedArrows.get(entityId);
        return last != null && (System.currentTimeMillis() - last) < ARROW_DEDUP_MS;
    }

    public void acceptArrowFallback(int entityId, BlockPos railPos, int cartDelay) {
        // Skip nếu primary path đã xử lý pos này
        if (pendingRails.containsKey(railPos) || pendingCarts.containsKey(railPos)) return;

        acceptedArrows.put(entityId, System.currentTimeMillis());
        AsyncRunner.runDelayed(() -> acceptedArrows.remove(entityId), ARROW_DEDUP_MS);

        pendingRails.put(railPos, new int[]{ 0, 0, 0 });
        pendingCarts.put(railPos, new int[]{ cartDelay, 0, 0, 0 });
    }

    // =================================================================
    // CLIENT TICK — đếm tick delay cho carts
    // =================================================================

    public void onClientTick(MinecraftClient mc) {
        if (!enabled) { pendingRails.clear(); pendingCarts.clear(); return; }
        if (mc.player == null || mc.world == null) return;

        // Rails: tick xuống, đánh dấu syncReady khi đến 0
        for (int[] state : pendingRails.values()) {
            if (state[1] == 1) continue; // đang chờ beforeSync
            if (state[0] > 0) state[0]--;
            else state[1] = 1; // syncReady
        }

        // Carts: tick xuống, đánh dấu syncReady khi đến 0
        for (int[] state : pendingCarts.values()) {
            if (state[2] == 1) continue;
            if (state[0] > 0) state[0]--;
            else state[2] = 1;
        }
    }

    // =================================================================
    // BEFORE SYNC — đặt block cùng movement packet (anti-cheat)
    // Gọi từ ClientPlayerEntityMixin.sendMovementPackets() HEAD
    // =================================================================

    public void beforeSync() {
        if (!enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // ---- Đặt Rails ----
        Iterator<Map.Entry<BlockPos, int[]>> railIter = pendingRails.entrySet().iterator();
        while (railIter.hasNext()) {
            Map.Entry<BlockPos, int[]> entry = railIter.next();
            BlockPos pos  = entry.getKey();
            int[]    state = entry.getValue();
            if (state[1] != 1) continue; // chưa đến giờ

            // Vị trí phải vẫn còn AIR — player có thể di chuyển
            if (!mc.world.getBlockState(pos).isAir()) {
                railIter.remove();
                // Nếu có block ở đó rồi (có thể là rail đặt trước), không xóa cart
                continue;
            }

            // Tìm slot ngay tại thời điểm đặt — không dùng slot cache
            SearchResult rail = InventoryUtil.findAny(Items.RAIL, Items.POWERED_RAIL);
            if (rail.isMissing()) {
                railIter.remove();
                pendingCarts.remove(pos); // không có rail → cancel cart cũng
                continue;
            }

            int savedSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = rail.slot;
            InteractionUtil.placeBelow(mc, pos);
            mc.player.getInventory().selectedSlot = savedSlot;
            railIter.remove();
        }

        // ---- Đặt Carts ----
        Iterator<Map.Entry<BlockPos, int[]>> cartIter = pendingCarts.entrySet().iterator();
        while (cartIter.hasNext()) {
            Map.Entry<BlockPos, int[]> entry = cartIter.next();
            BlockPos pos  = entry.getKey();
            int[]    state = entry.getValue(); // [0]=ticksLeft [1]=retryCount [2]=syncReady

            if (state[2] != 1) continue;

            boolean hasRail =
                mc.world.getBlockState(pos).isOf(Blocks.RAIL) ||
                mc.world.getBlockState(pos).isOf(Blocks.POWERED_RAIL);

            if (hasRail) {
                // Tìm slot ngay tại thời điểm đặt
                SearchResult cart = InventoryUtil.findItem(Items.TNT_MINECART);
                if (!cart.isMissing()) {
                    int saved = mc.player.getInventory().selectedSlot;
                    mc.player.getInventory().selectedSlot = cart.slot;
                    InteractionUtil.placeOnTop(mc, pos);
                    mc.player.getInventory().selectedSlot = saved;
                }
                cartIter.remove();
            } else if (state[1] < MAX_CART_RETRIES) {
                // Rail chưa spawn (server lag) → retry sau 1 tick
                state[0] = 1;
                state[2] = 0;
                state[1]++;
            } else {
                cartIter.remove(); // give up sau MAX_CART_RETRIES
            }
        }
    }
}
